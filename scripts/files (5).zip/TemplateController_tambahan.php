<?php
// TAMBAHKAN 2 method ini ke dalam class TemplateController
// File: app/Http/Controllers/Admin/TemplateController.php

// ── Method 1: Duplikat jenis surat ───────────────────────────────────────
public function duplicate(JenisSurat $jenisSurat)
{
    $baru = $jenisSurat->replicate();
    $baru->nama      = $jenisSurat->nama . ' (Salinan)';
    $baru->slug      = \Str::slug($baru->nama) . '-' . time();
    $baru->kode_surat = $jenisSurat->kode_surat ? $jenisSurat->kode_surat . '-COPY' : null;
    $baru->is_active = false;
    $baru->save();

    // Duplikat template jika ada
    if ($jenisSurat->template) {
        $templateBaru = $jenisSurat->template->replicate();
        $templateBaru->jenis_surat_id = $baru->id;
        $templateBaru->slug           = \Str::slug($baru->nama) . '-template-' . time();
        $templateBaru->is_active      = false;
        $templateBaru->save();
    }

    return redirect()
        ->route('admin.templates.index', ['jenis_surat_id' => $baru->id])
        ->with('success', "Jenis surat \"{$baru->nama}\" berhasil diduplikat.");
}

// ── Method 2: Toggle aktif/nonaktif ─────────────────────────────────────
public function toggleActive(JenisSurat $jenisSurat)
{
    $jenisSurat->update(['is_active' => !$jenisSurat->is_active]);

    $status = $jenisSurat->is_active ? 'diaktifkan' : 'dinonaktifkan';

    return back()->with('success', "Jenis surat \"{$jenisSurat->nama}\" berhasil {$status}.");
}
