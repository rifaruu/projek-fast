#!/usr/bin/env php
<?php
/**
 * FAST Academic — Rename & Restructure Script
 * ============================================
 * Jalankan dari root project: php scripts/restructure.php
 * Baca --dry-run dulu sebelum eksekusi nyata.
 *
 * Usage:
 *   php scripts/restructure.php --dry-run   (preview saja, tidak ada file berubah)
 *   php scripts/restructure.php             (eksekusi nyata)
 */

$dryRun = in_array('--dry-run', $argv ?? [], true);
$root   = rtrim(getcwd(), '/');

echo "\n";
echo "╔══════════════════════════════════════════════════════╗\n";
echo "║   FAST Academic — Restructure Script                 ║\n";
echo ($dryRun
    ? "║   MODE: DRY RUN (tidak ada file yang berubah)        ║\n"
    : "║   MODE: LIVE — file akan dipindah & diubah           ║\n");
echo "╚══════════════════════════════════════════════════════╝\n\n";

// ── Helpers ─────────────────────────────────────────────────────────────────

function log(string $msg, string $type = 'info'): void
{
    $prefix = match($type) {
        'ok'    => "\033[32m  ✓\033[0m",
        'move'  => "\033[34m  →\033[0m",
        'edit'  => "\033[33m  ~\033[0m",
        'skip'  => "\033[90m  ·\033[0m",
        'error' => "\033[31m  ✗\033[0m",
        'head'  => "\033[1m\n──",
        default => "   ",
    };
    echo "{$prefix} {$msg}\n";
}

function ensureDir(string $path, bool $dry): void
{
    if (!is_dir($path)) {
        if (!$dry) mkdir($path, 0755, true);
        log("mkdir {$path}", 'ok');
    }
}

function moveFile(string $from, string $to, bool $dry): bool
{
    global $root;
    $absFrom = "{$root}/{$from}";
    $absTo   = "{$root}/{$to}";

    if (!file_exists($absFrom)) {
        log("SKIP (tidak ada): {$from}", 'skip');
        return false;
    }

    ensureDir(dirname($absTo), $dry);

    if (!$dry) rename($absFrom, $absTo);
    log("{$from}  →  {$to}", 'move');
    return true;
}

function replaceInFile(string $file, array $replacements, bool $dry): void
{
    global $root;
    $absPath = "{$root}/{$file}";

    if (!file_exists($absPath)) {
        log("SKIP (tidak ada): {$file}", 'skip');
        return;
    }

    $original = file_get_contents($absPath);
    $updated  = str_replace(
        array_keys($replacements),
        array_values($replacements),
        $original
    );

    if ($original === $updated) {
        log("No change: {$file}", 'skip');
        return;
    }

    if (!$dry) file_put_contents($absPath, $updated);
    log("Updated: {$file}", 'edit');
    foreach ($replacements as $from => $to) {
        if (str_contains($original, $from)) {
            echo "        \033[90m{$from} → {$to}\033[0m\n";
        }
    }
}

function replaceInAllVue(string $dir, array $replacements, bool $dry): void
{
    global $root;
    $absDir = "{$root}/{$dir}";
    if (!is_dir($absDir)) return;

    $iter = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($absDir, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iter as $file) {
        if ($file->getExtension() === 'vue' || $file->getExtension() === 'ts') {
            $rel = str_replace($root.'/', '', $file->getPathname());
            replaceInFile($rel, $replacements, $dry);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 1 — Pindahkan Vue Layout
// ════════════════════════════════════════════════════════════════════════════

log('STEP 1 — Vue Layouts', 'head');

moveFile(
    'resources/js/layouts/fast/AdminWorkspaceLayout.vue',
    'resources/js/layouts/AdminLayout.vue',
    $dryRun
);

// ════════════════════════════════════════════════════════════════════════════
// STEP 2 — Pindahkan Vue Components
// ════════════════════════════════════════════════════════════════════════════

log('STEP 2 — Vue Components', 'head');

$componentMoves = [
    'resources/js/components/Fast/AdminSuratStepIndicator.vue' => 'resources/js/components/admin/LetterStepIndicator.vue',
    'resources/js/components/Fast/AdminSuratDynamicField.vue'  => 'resources/js/components/admin/DynamicField.vue',
    'resources/js/components/Fast/DynamicFormModal.vue'         => 'resources/js/components/admin/DynamicFormModal.vue',
];

foreach ($componentMoves as $from => $to) {
    moveFile($from, $to, $dryRun);
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 3 — Pindahkan Vue Pages (administrasi → admin)
// ════════════════════════════════════════════════════════════════════════════

log('STEP 3 — Vue Pages', 'head');

$pageMoves = [
    // Dashboard
    'resources/js/pages/fast/administrasi/DashboardAdmin.vue'         => 'resources/js/pages/admin/dashboard/Index.vue',
    // Letters (surat)
    'resources/js/pages/fast/administrasi/surat/Create.vue'            => 'resources/js/pages/admin/letters/Create.vue',
    'resources/js/pages/fast/administrasi/surat/Form.vue'              => 'resources/js/pages/admin/letters/Form.vue',
    'resources/js/pages/fast/administrasi/surat/Preview.vue'           => 'resources/js/pages/admin/letters/Preview.vue',
    // Templates
    'resources/js/pages/fast/administrasi/Templates.vue'               => 'resources/js/pages/admin/templates/Index.vue',
    // Approval
    'resources/js/pages/fast/approval/Dashboard.vue'                   => 'resources/js/pages/admin/approval/Index.vue',
    // QR
    'resources/js/pages/qr/VerifyResult.vue'                           => 'resources/js/pages/qr/VerifyResult.vue', // tetap
];

foreach ($pageMoves as $from => $to) {
    moveFile($from, $to, $dryRun);
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 4 — Pindahkan Controllers
// ════════════════════════════════════════════════════════════════════════════

log('STEP 4 — Controllers', 'head');

$controllerMoves = [
    'app/Http/Controllers/Fast/Administrasi/AdminDashboardController.php'   => 'app/Http/Controllers/Admin/DashboardController.php',
    'app/Http/Controllers/Fast/Administrasi/AdminSuratController.php'       => 'app/Http/Controllers/Admin/LetterController.php',
    'app/Http/Controllers/Fast/Administrasi/TemplateManagementController.php' => 'app/Http/Controllers/Admin/TemplateController.php',
    'app/Http/Controllers/Fast/Approval/DashboardController.php'            => 'app/Http/Controllers/Admin/ApprovalController.php',
    'app/Http/Controllers/Fast/User/DashboardController.php'               => 'app/Http/Controllers/User/DashboardController.php',
    'app/Http/Controllers/Fast/User/SubmissionController.php'              => 'app/Http/Controllers/User/SubmissionController.php',
    'app/Http/Controllers/Fast/User/JenisSuratFieldConfigController.php'   => 'app/Http/Controllers/User/LetterTypeController.php',
];

foreach ($controllerMoves as $from => $to) {
    moveFile($from, $to, $dryRun);
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 5 — Update namespace di Controllers baru
// ════════════════════════════════════════════════════════════════════════════

log('STEP 5 — Update namespace Controllers', 'head');

$controllerNamespaceUpdates = [
    'app/Http/Controllers/Admin/DashboardController.php' => [
        'namespace App\Http\Controllers\Fast\Administrasi;' => 'namespace App\Http\Controllers\Admin;',
        'class AdminDashboardController'                    => 'class DashboardController',
    ],
    'app/Http/Controllers/Admin/LetterController.php' => [
        'namespace App\Http\Controllers\Fast\Administrasi;' => 'namespace App\Http\Controllers\Admin;',
        'class AdminSuratController'                        => 'class LetterController',
    ],
    'app/Http/Controllers/Admin/TemplateController.php' => [
        'namespace App\Http\Controllers\Fast\Administrasi;' => 'namespace App\Http\Controllers\Admin;',
        'class TemplateManagementController'                => 'class TemplateController',
    ],
    'app/Http/Controllers/Admin/ApprovalController.php' => [
        'namespace App\Http\Controllers\Fast\Approval;' => 'namespace App\Http\Controllers\Admin;',
        'class DashboardController'                     => 'class ApprovalController',
    ],
    'app/Http/Controllers/User/DashboardController.php' => [
        'namespace App\Http\Controllers\Fast\User;' => 'namespace App\Http\Controllers\User;',
    ],
    'app/Http/Controllers/User/SubmissionController.php' => [
        'namespace App\Http\Controllers\Fast\User;' => 'namespace App\Http\Controllers\User;',
    ],
    'app/Http/Controllers/User/LetterTypeController.php' => [
        'namespace App\Http\Controllers\Fast\User;'         => 'namespace App\Http\Controllers\User;',
        'class JenisSuratFieldConfigController'             => 'class LetterTypeController',
    ],
];

foreach ($controllerNamespaceUpdates as $file => $replacements) {
    replaceInFile($file, $replacements, $dryRun);
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 6 — Update Inertia::render() di Controllers
// ════════════════════════════════════════════════════════════════════════════

log('STEP 6 — Update Inertia::render() path', 'head');

$renderUpdates = [
    'app/Http/Controllers/Admin/DashboardController.php' => [
        "'fast/administrasi/DashboardAdmin'"   => "'admin/dashboard/Index'",
    ],
    'app/Http/Controllers/Admin/LetterController.php' => [
        "'fast/administrasi/surat/Create'"     => "'admin/letters/Create'",
        "'fast/administrasi/surat/Form'"       => "'admin/letters/Form'",
        "'fast/administrasi/surat/Preview'"    => "'admin/letters/Preview'",
    ],
    'app/Http/Controllers/Admin/TemplateController.php' => [
        "'fast/administrasi/Templates'"        => "'admin/templates/Index'",
    ],
    'app/Http/Controllers/Admin/ApprovalController.php' => [
        "'fast/approval/Dashboard'"            => "'admin/approval/Index'",
    ],
    'app/Http/Controllers/User/DashboardController.php' => [
        "'fast/user/Dashboard'"                => "'user/Dashboard'",
    ],
    'app/Http/Controllers/User/SubmissionController.php' => [
        "'fast/user/"                          => "'user/",
    ],
];

foreach ($renderUpdates as $file => $replacements) {
    replaceInFile($file, $replacements, $dryRun);
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 7 — Update Vue imports (layout & components)
// ════════════════════════════════════════════════════════════════════════════

log('STEP 7 — Update Vue imports', 'head');

$vueImportReplacements = [
    // Layout
    "from '@/layouts/fast/AdminWorkspaceLayout.vue'"   => "from '@/layouts/AdminLayout.vue'",
    'from "@/layouts/fast/AdminWorkspaceLayout.vue"'   => 'from "@/layouts/AdminLayout.vue"',
    'AdminWorkspaceLayout'                             => 'AdminLayout',
    // Components
    "from '@/components/Fast/AdminSuratStepIndicator.vue'" => "from '@/components/admin/LetterStepIndicator.vue'",
    "from '@/components/Fast/AdminSuratDynamicField.vue'"  => "from '@/components/admin/DynamicField.vue'",
    'AdminSuratStepIndicator'                          => 'LetterStepIndicator',
    'AdminSuratDynamicField'                           => 'DynamicField',
];

// Update semua Vue & TS di pages/admin dan pages/user
replaceInAllVue('resources/js/pages/admin', $vueImportReplacements, $dryRun);
replaceInAllVue('resources/js/pages/user', $vueImportReplacements, $dryRun);

// ════════════════════════════════════════════════════════════════════════════
// STEP 8 — Update routes (use statements + class references)
// ════════════════════════════════════════════════════════════════════════════

log('STEP 8 — Update routes use statements', 'head');

// Cari semua file PHP di routes/
$routeFiles = glob($root.'/routes/*.php') ?: [];

$routeReplacements = [
    'App\Http\Controllers\Fast\Administrasi\AdminDashboardController'   => 'App\Http\Controllers\Admin\DashboardController',
    'AdminDashboardController'                                          => 'DashboardController',
    'App\Http\Controllers\Fast\Administrasi\AdminSuratController'       => 'App\Http\Controllers\Admin\LetterController',
    'AdminSuratController'                                              => 'LetterController',
    'App\Http\Controllers\Fast\Administrasi\TemplateManagementController' => 'App\Http\Controllers\Admin\TemplateController',
    'TemplateManagementController'                                      => 'TemplateController',
    'App\Http\Controllers\Fast\Approval\DashboardController'            => 'App\Http\Controllers\Admin\ApprovalController',
    'App\Http\Controllers\Fast\User\DashboardController'               => 'App\Http\Controllers\User\DashboardController',
    'App\Http\Controllers\Fast\User\SubmissionController'              => 'App\Http\Controllers\User\SubmissionController',
    'App\Http\Controllers\Fast\User\JenisSuratFieldConfigController'   => 'App\Http\Controllers\User\LetterTypeController',
    'JenisSuratFieldConfigController'                                  => 'LetterTypeController',
];

foreach ($routeFiles as $absPath) {
    $rel = str_replace($root.'/', '', $absPath);
    replaceInFile($rel, $routeReplacements, $dryRun);
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 9 — Update web.php redirect (redirect-dashboard)
// ════════════════════════════════════════════════════════════════════════════

log('STEP 9 — Update redirect di web.php', 'head');

replaceInFile('routes/web.php', [
    "return redirect()->route('admin.dashboard');"    => "return redirect()->route('admin.dashboard');", // tetap sama
], $dryRun);

// ════════════════════════════════════════════════════════════════════════════
// STEP 10 — Regenerate Wayfinder
// ════════════════════════════════════════════════════════════════════════════

log('STEP 10 — Regenerate Wayfinder', 'head');

if (!$dryRun) {
    log('Menjalankan: php artisan wayfinder:generate', 'info');
    passthru('php artisan wayfinder:generate');
    log('Wayfinder selesai di-generate', 'ok');
} else {
    log('[DRY RUN] Akan menjalankan: php artisan wayfinder:generate', 'skip');
}

// ════════════════════════════════════════════════════════════════════════════
// STEP 11 — Clear cache Laravel
// ════════════════════════════════════════════════════════════════════════════

log('STEP 11 — Clear cache Laravel', 'head');

if (!$dryRun) {
    passthru('php artisan route:clear');
    passthru('php artisan view:clear');
    passthru('php artisan config:clear');
    passthru('php artisan optimize');
    log('Cache berhasil dibersihkan', 'ok');
} else {
    log('[DRY RUN] Akan menjalankan: route:clear, view:clear, optimize', 'skip');
}

// ════════════════════════════════════════════════════════════════════════════
// Summary
// ════════════════════════════════════════════════════════════════════════════

echo "\n";
echo "╔══════════════════════════════════════════════════════╗\n";
echo ($dryRun
    ? "║   DRY RUN selesai. Tidak ada file yang diubah.       ║\n"
    : "║   Restructure selesai!                               ║\n");
echo "║   Langkah selanjutnya:                               ║\n";
echo "║   1. Cek manual — lihat IMPLEMENTATION_GUIDE.md     ║\n";
echo "║   2. npm run dev (atau vite build)                   ║\n";
echo "║   3. Test semua halaman admin                        ║\n";
echo "╚══════════════════════════════════════════════════════╝\n\n";
